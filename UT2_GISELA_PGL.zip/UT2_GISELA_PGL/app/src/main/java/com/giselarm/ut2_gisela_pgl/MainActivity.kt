package com.giselarm.ut2_gisela_pgl

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberBottomAppBarState
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.giselarm.ut2_gisela_pgl.ui.theme.UT2_GISELA_PGLTheme
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.firestore.FirebaseFirestore
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            //Comienzo de la actividad
            UT2_GISELA_PGLTheme() {
                /*Scaffold(modifier = Modifier.fillMaxSize()) {
                    MymenuDrawer()
                }*/
                Scaffold(modifier = Modifier.fillMaxSize()) {
                    MyMenuBottomBar()
                }
            }
        }
    }
}
//Método que se va a encargar de la pantalla de insertar. Los datos se recogen en la base de datos.
    @Composable
    fun Pantallainsertar() {
        val contexto = LocalContext.current
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Insertar", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            var id by remember { mutableStateOf("")}
            var nombre by remember { mutableStateOf("") }
            var anioBarco by remember { mutableStateOf("0") }
            OutlinedTextField(
                value = id,
                onValueChange = { id = it },
                label = { Text(text = "Identificador") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true
            )
            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text(text = "Nombre") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true
            )
            OutlinedTextField(
                value = anioBarco,
                onValueChange = { anioBarco = it },
                label = { Text(text = "Años que tiene el barco") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true
            )
            Button(
                onClick = {
                    val barcos = Barcos(id, nombre, anioBarco.toInt())
                    com.giselarm.ut2_gisela_pgl.barcos.document(id).set(barcos)
                    Toast.makeText(contexto, "Registro Insertado", Toast.LENGTH_SHORT).show()
                    id = ""
                    anioBarco = ""
                    nombre = ""
                }
            ) {
                Text("Insertar")
            }
        }
    }

//Método de la pantalla de búsqueda. Se van a buscar los datos por el identificador, mostrando luego los datos del barco con esa id.
    @Composable
    fun Pantallabuscar() {
        val contexto = LocalContext.current
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Buscar", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            var id by remember { mutableStateOf("") }
            var nombreBarco by remember { mutableStateOf("") }
            var anioBarco by remember { mutableStateOf("0") }
            OutlinedTextField(
                value = id,
                onValueChange = { id = it },
                label = { Text(text = "Identificador") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true
            )
            Text(text = "Nombre Barco: $nombreBarco")
            Text(text = "Año de embarcación: $anioBarco")
            Button(
                onClick = {
                    barcos.document(id.toString()).get().addOnSuccessListener {
                        if (it.exists()) {
                            id = it.get("id").toString()
                            nombreBarco = it.get("nombre").toString()
                            anioBarco = it.get("añobarco").toString()
                            Toast.makeText(contexto, "Registro encontrado", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(contexto, "Registro no encontrado", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            ) {
                Text("Buscar por id")
            }
        }
    }
//El StaticFieldLeak solo sirve para suprimir una advertencia, se añade solo si le das a suprimir en un fallo.
    @SuppressLint("StaticFieldLeak")
//Inicializar la base de datos
    val bd = FirebaseFirestore.getInstance()
    val barcos = bd.collection("Barcos")
    var barcoslist = mutableStateListOf<Barcos>()

//Data class para la base de datos (conector)
    data class Barcos(val id: String, val nombre: String, val año: Int) {
        override fun toString(): String {
            return "Barcos(id='$id', nombre='$nombre', años=$año)"
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)

    //Método para el menú con Drawer (menú lateral). Para hacer un bottombar, se puede hacer
    @Composable
    fun MymenuDrawer() {
        val navController = rememberNavController()
        val estadoDrawer = rememberDrawerState(initialValue = DrawerValue.Closed)
        val coroutineScope = rememberCoroutineScope()
        ModalNavigationDrawer(
            drawerContent = {
                ModalDrawerSheet {
                    Text(
                        text = "Menu",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    NavigationDrawerItem(
                        label = { Text("Mapa")},
                        selected = false,
                        onClick = {
                            navController.navigate("mapa")
                            coroutineScope.launch { estadoDrawer.close()}
                        },
                        icon = { Icon(Icons.Filled.Home, null) }
                    )
                    NavigationDrawerItem(
                        label = { Text("Corrutina")},
                        selected = false,
                        onClick = {
                            navController.navigate("corrutina")
                            coroutineScope.launch { estadoDrawer.close()}
                        },
                        icon = { Icon(Icons.Filled.Build, null) }
                    )
                    NavigationDrawerItem(
                        label = { Text("Insertar")},
                        selected = false,
                        onClick = {
                            navController.navigate("insertar")
                            coroutineScope.launch { estadoDrawer.close()}
                        },
                        icon = { Icon(Icons.Filled.Add, null) }
                    )
                    NavigationDrawerItem(
                        label = { Text("Buscar")},
                        selected = false,
                        onClick = {
                            navController.navigate("buscar")
                            coroutineScope.launch { estadoDrawer.close()}
                        },
                        icon = {Icon(Icons.Filled.Search, null)}
                    )
                    NavigationDrawerItem(
                        label = { Text("Eliminar")},
                        selected = false,
                        onClick = {
                            navController.navigate("eliminar")
                            coroutineScope.launch { estadoDrawer.close()}
                        },
                        icon = {Icon(Icons.Filled.Delete, null)}
                    )
                    NavigationDrawerItem(
                        label = { Text("Actualizar")},
                        selected = false,
                        onClick = {
                            navController.navigate("actualizar")
                            coroutineScope.launch { estadoDrawer.close()}
                        },
                        icon = {Icon(Icons.Filled.Edit, null)}
                    )
                    NavigationDrawerItem(
                        label = { Text("Todos")},
                        selected = false,
                        onClick = {
                            rellenaLista()
                            navController.navigate("todos")
                            coroutineScope.launch { estadoDrawer.close()}
                        },
                        icon = {Icon(Icons.Filled.Menu, null)}
                    )
                }
            },
            drawerState = estadoDrawer
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Text("UT2 GISELA PGL")
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = {
                                    coroutineScope.launch { estadoDrawer.open() }
                                }
                            ) {
                                Icon(Icons.Filled.Menu, contentDescription = null)
                            }
                        }
                    )
                },
                content = { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "mapa",
                        Modifier.padding(innerPadding)
                    ) {
                        composable("mapa") {
                            Pantallainicio()
                        }
                        composable("corrutina") {
                            Pantallacorrutina()
                        }
                        composable("insertar") {
                            Pantallainsertar()
                        }
                        composable("buscar") {
                            Pantallabuscar()
                        }
                        composable("eliminar") {
                            Pantallaeliminar()
                        }
                        composable("actualizar") {
                            Pantallaactualizar()
                        }
                        composable("todos") {
                            Pantallatodos()
                        }
                    }
                }
            )
        }
    }

@Composable
fun MyMenuBottomBar() {
    val navController = rememberNavController()
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    label = { Text("Mapa") },
                    selected = true,
                    onClick = {
                        navController.navigate("mapa")
                    },
                    icon = { Icon(Icons.Filled.Home, null) }
                )
                NavigationBarItem(
                    label = { Text("Corrutina") },
                    selected = false,
                    onClick = {
                        navController.navigate("corrutina")
                    },
                    icon = { Icon(Icons.Filled.Build, null) }
                )
                NavigationBarItem(
                    label = { Text("Insertar") },
                    selected = false,
                    onClick = {
                        navController.navigate("insertar")
                    },
                    icon = { Icon(Icons.Filled.Add, null) }
                )
                NavigationBarItem(
                    label = { Text("Buscar") },
                    selected = false,
                    onClick = {
                        navController.navigate("buscar")
                    },
                    icon = { Icon(Icons.Filled.Search, null) }
                )
                NavigationBarItem(
                    label = { Text("Eliminar") },
                    selected = false,
                    onClick = {
                        navController.navigate("eliminar")
                    },
                    icon = { Icon(Icons.Filled.Delete, null) }
                )
                NavigationBarItem(
                    label = { Text("Actualizar") },
                    selected = false,
                    onClick = {
                        navController.navigate("actualizar")
                    },
                    icon = { Icon(Icons.Filled.Edit, null) }
                )
                NavigationBarItem(
                    label = { Text("Todos") },
                    selected = false,
                    onClick = {
                        rellenaLista()
                        navController.navigate("todos")
                    },
                    icon = { Icon(Icons.Filled.Menu, null) }
                )
            }
        }
    ) {
        innerPadding ->
            NavHost(
                navController = navController,
                startDestination = "mapa",
                Modifier.padding(innerPadding)
            ) {
                composable("mapa") {
                    Pantallainicio()
                }
                composable("corrutina") {
                    Pantallacorrutina()
                }
                composable("insertar") {
                    Pantallainsertar()
                }
                composable("buscar") {
                    Pantallabuscar()
                }
                composable("eliminar") {
                    Pantallaeliminar()
                }
                composable("actualizar") {
                    Pantallaactualizar()
                }
                composable("todos") {
                    Pantallatodos()
                }
            }
        }
    }



//Método que te muestra todos los datos guardados en la base de datos
    @Composable
    fun Pantallatodos() {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            items(barcoslist) {
                    embarcacion -> MostrarBarcos(embarcacion)
            }
        }
    }
//Método que de muestra los barcos que hay en la base de datos
    @Composable
    fun MostrarBarcos(eq: Barcos) {
        HorizontalDivider(modifier = Modifier.fillMaxWidth().width(16.dp))
        Text(text = "Identificador: ${eq.id}")
        Text(text = "Nombre: ${eq.nombre}")
        Text(text = "Años que tiene el barco: ${eq.año.toString()}")
        HorizontalDivider(modifier = Modifier.fillMaxWidth().width(16.dp))
    }
//Método que rellena la lista de datos si no lo está
    private fun rellenaLista() {
        barcoslist.clear()
        barcos.get().addOnSuccessListener {
            for(docum in it) {
                val equ = Barcos(
                    docum.data.get("id").toString(),
                    docum.data.get("nombre").toString(),
                    docum.data.get("año").toString().toInt(),
                )
                barcoslist.add(equ)
            }
        }
    }
//Método que te permite ir a la pantala de actualizar y modificar un dato (el que el usuario ingrese)
    @Composable
    fun Pantallaactualizar() {
        val contexto = LocalContext.current
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Actualizar", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            var id by remember { mutableStateOf("")}
            var nombre by remember { mutableStateOf("") }
            var anioBaja by remember { mutableStateOf("0") }
            OutlinedTextField(
                value = id,
                onValueChange = { id = it },
                label = { Text(text = "Identificador") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true
            )
            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text(text = "Nombre") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true
            )
            OutlinedTextField(
                value = anioBaja,
                onValueChange = { anioBaja = it },
                label = { Text(text = "Año de baja del barco") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true
            )
            Button(
                onClick = {
                    barcos.document(id.toString()).set(hashMapOf("id" to id.toString(), "nombre" to nombre.toString(), "año" to anioBaja.toInt()))
                    Toast.makeText(contexto, "Registro Actualizado", Toast.LENGTH_SHORT).show()
                    id = ""
                    anioBaja = ""
                    nombre = ""
                }
            ) {
                Text("Actualizar")
            }
        }
    }
//Método para eliminar un dato, te manda a la pantalla de eliminar y por la ID se elimina el dato
    @Composable
    fun Pantallaeliminar() {
        val contexto = LocalContext.current
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Eliminar", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            var id by remember { mutableStateOf("") }
            OutlinedTextField(
                value = id,
                onValueChange = { id = it },
                label = { Text(text = "Identificador") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true
            )
            Button(
                onClick = {
                    barcos.document(id.toString()).get().addOnSuccessListener {
                        if (it.exists()) {
                            it.reference.delete()
                            Toast.makeText(contexto, "Registro eliminado", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(contexto, "Registro no encontrado", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            ) {
                Text("Borrar por id")
            }
        }
    }

//Método de pabtalla de inicio, muestra el mapa y la localización que he puesto en el código
    @Composable
    fun Pantallainicio() {
        val muelle = LatLng(27.8175, -15.76528)
        val cameraPositionState = rememberCameraPositionState{
            position = CameraPosition.fromLatLngZoom(muelle,10f)
        }
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState
        ) {
            Marker(
                state = MarkerState(position = muelle),
                title = "Puerto de Mogán",
                snippet = "Marcador en el Puerto de Mogán"
            )
        }
    }

//Método de la corrutina, el programa lanza una cuenta atrás desde el número que indique el usuario hasta el número 0
@Composable
fun Pantallacorrutina() {
    var puerto by remember { mutableStateOf("") }
    var mensajeBarco by remember { mutableStateOf("Inicio") }
    val capitanCorrutina = rememberCoroutineScope()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Corrutinas - Barco", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = puerto,
            onValueChange = { puerto = it },
            label = { Text(text = "Identificador del Puerto") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(mensajeBarco)
        Button(
            onClick = {
                capitanCorrutina.launch(Dispatchers.Default) {
                    if (puerto.toInt() > 0) {
                        for (marinero in puerto.toInt() downTo 0) {
                            simulaTarea()
                            mensajeBarco = "$marinero"
                        }
                        mensajeBarco = "Corrutina finalizada"
                    }
                }
            }
        ) {
            Text(text = "Comenzar")
        }
    }
}
//Método utilizado en el método anterior
fun simulaTarea() {
        try {
            Thread.sleep(1000)
        } catch (_: InterruptedException) {}
    }



















